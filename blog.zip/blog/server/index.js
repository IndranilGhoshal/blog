const express = require('express')
const app = express();
var http = require('http');
var bodyParser = require('body-parser');
const port = 9000;
router = require("./router/router")
var cros = require('cors')
var path = require('path')
app.use(cros({origin:true}));
app.options('*',cros())
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

app.get('/', (req, res) => {
  res.send('Hello World!')
});
app.use('/api', router);

var httpsServer = http.createServer(app);
httpsServer.listen(port);
console.log('RESTful API server started on: ' + port);
