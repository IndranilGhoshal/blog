import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "../modules/login/index";
import Home from "../modules/Public/Home/index";
import Layout from "../modules/Public/Layout/index";
import Register from "../modules/register/index";
import AddPost from "../modules/Public/AddPost/index";
import ViewPost from "../modules/Public/ViewPost/index";
import EditPost from "../modules/Public/EditPost/index";
export default function routing() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />

                <Route path="/" element={<Layout />}>
                    <Route index element={<Home />} />
                    <Route path="/addpost" element={<AddPost />} />
                    <Route path="/viewpost/:id" element={<ViewPost />} />
                    <Route path="/editpost/:id" element={<EditPost />} />
                </Route>

            </Routes>
        </BrowserRouter>
    );
}