const db = require('../database/dbConn');
const common = require('../services/commonService');

module.exports.addPost = (data) => {
	return new Promise((resolve, reject) => {
		try {
            console.log(data)
			var sql 	=	"INSERT INTO `posts`(`userid`, `title`, `content`, `author`) VALUES ('"+data.userid+"','"+data.title+"','"+data.content+"','"+data.author+"')";
			db.connection.query(sql,function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}

module.exports.allPost  = (data) => {
	return new Promise((resolve, reject) => {
		try {
			var sql 	=	"SELECT `id`, `userid`, `title`, `content`, `author` FROM `posts` WHERE isdelete=0";
			db.connection.query(sql,async function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}

module.exports.getPostbyId  = (data) => {
	return new Promise((resolve, reject) => {
		try {
			var sql 	=	"SELECT `id`, `userid`, `title`, `content`, `author` FROM `posts` WHERE id='"+data.id+"'  AND isdelete=0";
			db.connection.query(sql,async function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}

module.exports.editPost = (data) => {
	return new Promise((resolve, reject) => {
		try {
			var sql 	=	"UPDATE `posts` SET `title`='"+data.title+"',`content`='"+data.content+"' WHERE id='"+data.id+"'";
			db.connection.query(sql,function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}

module.exports.deletePost = (data) => {
	return new Promise((resolve, reject) => {
		try {
			var sql 	=	"UPDATE `posts` SET `isdelete`='1' WHERE id='"+data.id+"'";
			db.connection.query(sql,function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}