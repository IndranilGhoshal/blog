import React, { useState } from 'react'
import Page from './page'
import { useNavigate } from 'react-router-dom'
import { register } from '../../service/rest';
import { errorMsg, successMsg } from '../../service/common';

export default function Register() {
    const navigate = useNavigate();
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [nameErr, setNameErr] = useState(false)
    const [emailErr, setEmailErr] = useState(false)
    const [passwordErr, setPasswordErr] = useState(false)

    const getEmail = (val) => {
        setEmail(val)
        setEmailErr(false)
    }

    const getPassword = (val) => {
        setPassword(val)
        setPasswordErr(false)
    }

    const getName = (val) => {
        setName(val)
        setNameErr(false)
    }

    const onSignup = () => {
        let err = 0;
        setNameErr(false)
        setEmailErr(false)
        setPasswordErr(false)

        if (name === '' || name === undefined || name === null) {
            setNameErr(true)
            err++
        }

        if (email === '' || email === undefined || email === null) {
            setEmailErr(true)
            err++
        }

        if (password === '' || password === undefined || password === null) {
            setPasswordErr(true)
            err++
        }

        if (err === 0) {
            let data = {
                name: name,
                email: email,
                password: password
            }
            register(data).then((result) => {
                if (result.data.success) {
                    successMsg(result.data.message)
                    setTimeout(() => {
                        navigate("/login")
                    }, 1000);
                } else {
                    errorMsg(result.data.message)
                }
            })
        }
    }

    const goto = (path) =>{
        navigate(path)
      }

    return (
        <Page
        onSignup={onSignup}
        name={name}
        nameErr={nameErr}
            email={email}
            password={password}
            emailErr={emailErr}
            passwordErr={passwordErr}

            getEmail={getEmail}
            getPassword={getPassword}
            getName={getName}
            goto={goto}
        />
    )
}
