const dao = require('../dao/comment_dao');
const common = require('../services/commonService');
const express = require('express');
const router = express.Router();
module.exports = router;

router.post('/addComment', async (req, res) => {
	try{
		if (req.body.userid === undefined || req.body.postid === undefined ||  req.body.content === undefined) {
			res.send(common.sendResponse(false, 0, 'userid, postid, content missing', null, 401))
		} else {
			const result = await dao.addComment(req.body);
			if (result.error) {
				res.send(common.sendResponse(false, 0, 'Some error occurred', null, 500));
			} else {
				let message = 'Comment added succesfully'
				res.send(common.sendResponse(true, 1, message, null, 0));
			}
		}
	} catch(e) {
        console.log(e)
        res.send(common.sendResponse(false, 0, 'Something went wrong. Please try again.', null, 1002));
	}
});

router.post('/allComment', async (req, res) => {
	try{
		const result = await dao.allComment(req.body);
		if (result.error) {
			res.send(common.sendResponse(false, 0, 'Some error occurred', null, 500));
		} else {
			let message = '';
			res.send(common.sendResponse(true, 1, message, result, 0));
		}
	} catch(e) {
        console.log(e)
        res.send(common.sendResponse(false, 0, 'Something went wrong. Please try again.', null, 1002));
	}
});

router.post('/editComment', async (req, res) => {
	try{
		if (req.body.id === undefined || req.body.userid === undefined || req.body.postid === undefined ||  req.body.content === undefined) {
			res.send(common.sendResponse(false, 0, 'id, userid, postid, content missing', null, 401))
		} else {
			const result = await dao.editComment(req.body);
			if (result.error) {
				res.send(common.sendResponse(false, 0, 'Some error occurred', null, 500));
			} else {
				let message = 'Comment update succesfully'
				res.send(common.sendResponse(true, 1, message, null, 0));
			}
		}
	} catch(e) {
        console.log(e)
        res.send(common.sendResponse(false, 0, 'Something went wrong. Please try again.', null, 1002));
	}
});

router.post('/deleteComment', async (req, res) => {
	try{
		if (req.body.id === undefined) {
			res.send(common.sendResponse(false, 0, 'id missing', null, 401))
		} else {
			const result = await dao.deleteComment(req.body);
			if (result.error) {
				res.send(common.sendResponse(false, 0, 'Some error occurred', null, 500));
			} else {
				let message = 'Comment delete succesfully'
				res.send(common.sendResponse(true, 1, message, null, 0));
			}
		}
	} catch(e) {
        console.log(e)
        res.send(common.sendResponse(false, 0, 'Something went wrong. Please try again.', null, 1002));
	}
});