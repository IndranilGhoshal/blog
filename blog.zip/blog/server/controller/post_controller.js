const dao = require('../dao/post_dao');
const common = require('../services/commonService');
const express = require('express');
const router = express.Router();
module.exports = router;

router.post('/addPost', async (req, res) => {
	try{
		if (req.body.userid === undefined || req.body.title === undefined ||  req.body.content === undefined|| req.body.author === undefined) {
			res.send(common.sendResponse(false, 0, 'userid, title,content,author missing', null, 401))
		} else {
			const result = await dao.addPost(req.body);
			if (result.error) {
				res.send(common.sendResponse(false, 0, 'Some error occurred', null, 500));
			} else {
				let message = 'Post added succesfully'
				res.send(common.sendResponse(true, 1, message, null, 0));
			}
		}
	} catch(e) {
        console.log(e)
        res.send(common.sendResponse(false, 0, 'Something went wrong. Please try again.', null, 1002));
	}
});

router.post('/allPost', async (req, res) => {
	try{
		const result = await dao.allPost(req.body);
		if (result.error) {
			res.send(common.sendResponse(false, 0, 'Some error occurred', null, 500));
		} else {
			let message = '';
			res.send(common.sendResponse(true, 1, message, result, 0));
		}
	} catch(e) {
        console.log(e)
        res.send(common.sendResponse(false, 0, 'Something went wrong. Please try again.', null, 1002));
	}
});

router.post('/getPostbyId', async (req, res) => {
	try{
		const result = await dao.getPostbyId(req.body);
		if (result.error) {
			res.send(common.sendResponse(false, 0, 'Some error occurred', null, 500));
		} else {
			let message = '';
			res.send(common.sendResponse(true, 1, message, result[0], 0));
		}
	} catch(e) {
        console.log(e)
        res.send(common.sendResponse(false, 0, 'Something went wrong. Please try again.', null, 1002));
	}
});

router.post('/editPost', async (req, res) => {
	try{
		if (req.body.id === undefined || req.body.title === undefined ||  req.body.content === undefined) {
			res.send(common.sendResponse(false, 0, 'id, title, content missing', null, 401))
		} else {
			const result = await dao.editPost(req.body);
			if (result.error) {
				res.send(common.sendResponse(false, 0, 'Some error occurred', null, 500));
			} else {
				let message = 'Post update succesfully'
				res.send(common.sendResponse(true, 1, message, null, 0));
			}
		}
	} catch(e) {
        console.log(e)
        res.send(common.sendResponse(false, 0, 'Something went wrong. Please try again.', null, 1002));
	}
});

router.post('/deletePost', async (req, res) => {
	try{
		if (req.body.id === undefined) {
			res.send(common.sendResponse(false, 0, 'id missing', null, 401))
		} else {
			const result = await dao.deletePost(req.body);
			if (result.error) {
				res.send(common.sendResponse(false, 0, 'Some error occurred', null, 500));
			} else {
				let message = 'Post delete succesfully'
				res.send(common.sendResponse(true, 1, message, null, 0));
			}
		}
	} catch(e) {
        console.log(e)
        res.send(common.sendResponse(false, 0, 'Something went wrong. Please try again.', null, 1002));
	}
});