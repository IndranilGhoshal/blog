import React from 'react'
import { NotificationContainer } from 'react-notifications'

export default function page(props) {
    return (
        <>
            <div className='add_pst_bdy'>
                <div className='row'>
                    <div className='col-sm-12 my-3'>
                        <div className='add_pst_txt'>Add Post</div>
                    </div>
                    <div className='col-sm-8 mb-3'>
                        <label className='input_label'>Title</label>
                        <input
                            type='text'
                            className={`form-control input ${props.titleErr ? 'error_fill' : ''}`}
                            value={props.title}
                            onChange={(e) => { props.getTitle(e.target.value) }}
                        />
                        {
                            props.titleErr ? <span className='error_text'>Title reqired!</span> : null
                        }
                    </div>
                    <div className='col-sm-8 mb-3'>
                        <label className='input_label'>Content</label>
                        <textarea
                            className={`form-control input ${props.contentErr ? 'error_fill' : ''}`}
                            value={props.content}
                            onChange={(e) => { props.getContent(e.target.value) }}
                        >
                        </textarea>
                        {
                            props.contentErr ? <span className='error_text'>Content reqired!</span> : null
                        }
                    </div>
                    <div className='col-sm-4 mb-3'>

                    </div>

                    <div className='col-sm-3 mb-3'>
                        <button className='btn btn-primary log_btn' onClick={()=>{props.onSubmit()}}>Add Post</button>
                    </div>
                </div>
            </div>
            <NotificationContainer/>
        </>
    )
}
