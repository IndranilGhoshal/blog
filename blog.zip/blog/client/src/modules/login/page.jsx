import React from 'react'
import {NotificationContainer} from 'react-notifications';

export default function page(props) {
  return (
    <>
      <div className='login_by'>
        <div className='login_head'>
          <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" className="bi bi-door-open" viewBox="0 0 16 16">
            <path d="M8.5 10c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1" />
            <path d="M10.828.122A.5.5 0 0 1 11 .5V1h.5A1.5 1.5 0 0 1 13 2.5V15h1.5a.5.5 0 0 1 0 1h-13a.5.5 0 0 1 0-1H3V1.5a.5.5 0 0 1 .43-.495l7-1a.5.5 0 0 1 .398.117M11.5 2H11v13h1V2.5a.5.5 0 0 0-.5-.5M4 1.934V15h6V1.077z" />
          </svg>
          <span className='mx-2'>Login</span>
        </div>
        <div className='login_body'>
          <div className='mb-2'>
            <label className='input_label'>Email</label>
            <input 
            type='text' 
            className={`form-control input ${props.emailErr ? 'error_fill':''}`} 
            value={props.email}
            onChange={(e)=>{props.getEmail(e.target.value)}}
            />
            {
              props.emailErr ? <span className='error_text'>Email reqired!</span> : null
            }
          </div>
          <div className='mb-3'>
            <label className='input_label'>Password</label>
            <input 
            type='password' 
            className={`form-control input ${props.passwordErr ? 'error_fill':''}`} 
            value={props.password}
            onChange={(e)=>{props.getPassword(e.target.value)}}
            />
            {
              props.passwordErr ? <span className='error_text'>Password reqired!</span> : null
            }
          </div>
          <div>
            <button className='btn btn-primary log_btn' onClick={()=>{props.onLogin()}}>Login</button>
          </div>
          <div className='mt-3 text-center'>
            <div>No account ? <span className='cursor-pointer' style={{color:"blue"}} onClick={()=>{props.goto('/register')}}>Create one</span> </div>
          </div>
        </div>
      </div>

      <NotificationContainer/>
    </>
  )
}
