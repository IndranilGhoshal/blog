import React, { useState } from 'react'
import Page from './page'
import { useNavigate } from 'react-router-dom';
import { errorMsg, getUser, successMsg } from '../../../service/common';
import { addPost } from '../../../service/rest';
export default function AddPost() {

  const navigate = useNavigate();
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [titleErr, setTitleErr] = useState(false)
  const [contentErr, setContentErr] = useState(false)

  const getTitle = (val) => {
    setTitle(val)
    setTitleErr(false)
  }

  const getContent = (val) => {
    setContent(val)
    setContentErr(false)
  }

  const onSubmit = () => {
    let err = 0;
    setTitleErr(false)
    setContentErr(false)

    if (title === '' || title === undefined || title === null) {
      setTitleErr(true)
      err++
    }

    if (content === '' || content === undefined || content === null) {
      setContentErr(true)
      err++
    }

    if (err === 0) {
      let data = {
        userid:getUser().id,
        title:title,
        content:content,
        author:getUser().name
      }
      addPost(data).then((result) => {
        if (result.data.success) {
          successMsg(result.data.message)
          navigate("/")
        } else {
          errorMsg(result.data.message)
        }
      })
    }
  }

  const goto = (path) =>{
    navigate(path)
  }



  return (
    <Page 
    title={title}
    content={content}
    titleErr={titleErr}
    contentErr={contentErr}

    getTitle={getTitle}
    getContent={getContent}
    onSubmit={onSubmit}
    goto={goto}
    />
  )
}
