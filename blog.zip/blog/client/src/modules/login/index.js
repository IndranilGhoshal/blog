import React, { useEffect, useState } from 'react'
import Page from './page'
import { useNavigate } from 'react-router-dom'
import { login } from '../../service/rest';
import { errorMsg, getUser } from '../../service/common';

export default function Login() {
  useEffect(()=>{
    if(getUser()){
      navigate('/')
    }
  },[])
  const navigate = useNavigate();
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [emailErr, setEmailErr] = useState(false)
  const [passwordErr, setPasswordErr] = useState(false)

  const getEmail = (val) => {
    setEmail(val)
    setEmailErr(false)
  }

  const getPassword = (val) => {
    setPassword(val)
    setPasswordErr(false)
  }

  const onLogin = () => {
    let err = 0;
    setEmailErr(false)
    setPasswordErr(false)

    if (email === '' || email === undefined || email === null) {
      setEmailErr(true)
      err++
    }

    if (password === '' || password === undefined || password === null) {
      setPasswordErr(true)
      err++
    }

    if (err === 0) {
      let data = {
        email: email,
        password: password
      }
      login(data).then((result) => {
        if (result.data.success) {
          sessionStorage.setItem('user', JSON.stringify(result.data.response))
          navigate("/")
        } else {
          errorMsg(result.data.message)
        }
      })
    }
  }

  const goto = (path) =>{
    navigate(path)
  }

  return (
    <Page
      onLogin={onLogin}

      email={email}
      password={password}
      emailErr={emailErr}
      passwordErr={passwordErr}

      getEmail={getEmail}
      getPassword={getPassword}
      goto={goto}
    />
  )
}
