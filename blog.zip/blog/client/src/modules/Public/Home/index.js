import React, { useEffect, useState } from 'react'
import Page from './page'
import { getUser } from '../../../service/common'
import { useNavigate } from 'react-router-dom'
import { allPost } from '../../../service/rest'
export default function Home() {
  const navigate = useNavigate()
  const [postArr, setPostArr] = useState([])
  useEffect(()=>{
    if(!getUser()){
      navigate('/login')
    }
    allPostFun()
  },[])

  const allPostFun =()=>{
    allPost({}).then((result)=>{
      if(result.data.success){
        setPostArr(result.data.response)
      }else{
        setPostArr([])
      }
    })
  }

  const goto = (path) =>{
    navigate(path)
  }

  return (
    <Page
    postArr={postArr} 
    goto={goto}
    />
  )
}
