const db = require('../database/dbConn');
const common = require('../services/commonService');

module.exports.addComment = (data) => {
	return new Promise((resolve, reject) => {
		try {
			var sql 	=	"INSERT INTO `comments`(`userid`, `postid`, `content`) VALUES ('"+data.userid+"','"+data.postid+"','"+data.content+"')";
			db.connection.query(sql,function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}

module.exports.allComment  = (data) => {
	return new Promise((resolve, reject) => {
		try {
			var sql 	=	"SELECT com.id, com.userid, com.postid, com.content, user.name FROM `comments` as com, `users` as user  WHERE com.postid = '"+data.postid+"' AND com.userid=user.id AND com.isdelete=0 ORDER BY com.id ASC";
			db.connection.query(sql,async function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}

module.exports.editComment = (data) => {
	return new Promise((resolve, reject) => {
		try {
			var sql 	=	"UPDATE `comments` SET `content`='"+data.content+"' WHERE id='"+data.id+"'";
			db.connection.query(sql,function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}

module.exports.deleteComment = (data) => {
	return new Promise((resolve, reject) => {
		try {
			var sql 	=	"UPDATE `comments` SET `isdelete`='1' WHERE id='"+data.id+"'";
			db.connection.query(sql,function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}