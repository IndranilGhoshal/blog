import axios from "axios";
import { BASE_URL } from "../config/config";

export function login(data) {
    return axios.post(BASE_URL + '/user/login', data);
}

export function register(data) {
    return axios.post(BASE_URL + '/user/register', data);
}

export function addPost(data) {
    return axios.post(BASE_URL + '/post/addPost', data);
}

export function allPost(data) {
    return axios.post(BASE_URL + '/post/allPost', data);
}

export function getPostbyId(data) {
    return axios.post(BASE_URL + '/post/getPostbyId', data);
}


export function addComment(data) {
    return axios.post(BASE_URL + '/comment/addComment', data);
}

export function allComment(data) {
    return axios.post(BASE_URL + '/comment/allComment', data);
}

export function editPost(data) {
    return axios.post(BASE_URL + '/post/editPost', data);
}

export function deletePost(data) {
    return axios.post(BASE_URL + '/post/deletePost', data);
}