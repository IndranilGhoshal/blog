import React from 'react'
import { NotificationContainer } from 'react-notifications'
import { getUser } from '../../../service/common'

export default function page(props) {
    return (
        <>
            <div className='hm_bdy'>
                <div className='pst_hd_txt my-3'>View Posts</div>
                <div>
                    <div className={`pst_crd`}>
                        <div className='row'>
                            <div className='col-sm-6'>
                                <div className='crd_txt_1'>
                                    Title
                                </div>
                                <div className='crd_txt_2'>
                                    {props.post.title}
                                </div>
                            </div>
                            {
                                getUser().id === props.post.userid ?
                                    <div className='col-sm-6 ' style={{ textAlign: "right" }}>
                                        <button className='eidt_btn' onClick={() => { props.goto("/editpost/" + props.post.id) }}>Edit</button>
                                        <button className='dtl_btn mx-2' onClick={() => { props.onDelete(props.post.id) }}>Delete</button>
                                    </div> : null

                            }

                            <div className='col-sm-12 '>
                                <div className='crd_txt_1'>
                                    Auther
                                </div>
                                <div className='crd_txt_2'>
                                    {props.post.author}
                                </div>
                            </div>
                            <div className='col-sm-12 mb-2'>
                                <div className='crd_txt_1'>
                                    Content
                                </div>
                                <div className='crd_txt_2'>
                                    {props.post.content}
                                </div>
                            </div>

                            {
                                props.comment.length > 0 ?
                                    <>
                                        <div className='col-sm-12 mb-2'>
                                            <div className='crd_txt_1'>
                                                All Comments
                                            </div>
                                            <div >
                                                {
                                                    props.comment.map((item, i) => (
                                                        <div style={{ display: "flex" }}>
                                                            <div className='cmt_nam_txt'>
                                                                {item.name}
                                                            </div>
                                                            <div className='cmt_nam_cmt mx-2'>
                                                                {item.content}
                                                            </div>
                                                        </div>
                                                    ))
                                                }
                                            </div>
                                        </div>
                                    </>
                                    :
                                    null
                            }

                            <div className='col-sm-12 mb-2'>
                                <div className='cmt_inp'>
                                    <textarea
                                        className={`form-control input ${props.contentErr ? 'error_fill' : ''}`}
                                        value={props.content}
                                        onChange={(e) => { props.getContent(e.target.value) }}
                                    >
                                    </textarea>
                                    {
                                        props.contentErr ? <span className='error_text'>Comment reqired!</span> : null
                                    }
                                </div>
                                <button className='add_btn_cmt my-2' onClick={() => { props.onSubmit() }}>Add Commnet</button>
                            </div>


                        </div>

                    </div>
                </div>
            </div>
            <NotificationContainer />
        </>
    )
}
