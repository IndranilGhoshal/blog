
import './App.css';
import Routing from './routing/routing';
import './assets/css/style.css'
import 'react-notifications/lib/notifications.css';

function App() {
  return (
    <Routing />
  );
}

export default App;
