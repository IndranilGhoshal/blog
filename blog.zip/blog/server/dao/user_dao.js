const db = require('../database/dbConn');
const common = require('../services/commonService');

module.exports.login = (data) => {
	return new Promise((resolve, reject) => {
		try {
            console.log(data)
			var sql 	=	"SELECT `id`, `name`, `email`, `password` FROM `users` WHERE `email`='"+data.email+"' AND password = '"+data.password+"' AND isdelete =0";
			db.connection.query(sql,function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    console.log(success)
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}

module.exports.alreadyUserExist = (data) =>{
	return new Promise((resolve, reject)=>{
		try{
			var sql = "SELECT `id` FROM `users` WHERE `email`='"+data.email+"' AND isdelete =0"
			db.connection.query(sql,function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    console.log(success)
                    resolve(success)
                }
            });
		}catch(e){
			console.log(e)
			resolve('500')
		}
	})
}

module.exports.register = (data) => {
	return new Promise((resolve, reject) => {
		try {
			var sql 	=	"INSERT INTO `users`(`name`, `email`, `password`) VALUES ('"+data.name+"','"+data.email+"','"+data.password+"')";
			db.connection.query(sql,function (err, success){
                if (err) {
                    resolve(common.errorResolve(err))
                } else {
                    resolve(success)
                }
            });
		} catch (e) {
			console.log(e);
			resolve('500');
		}
	});
}