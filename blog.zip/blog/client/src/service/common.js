import {NotificationManager} from 'react-notifications';

export const successMsg = (data) =>{
    NotificationManager.success(data);
}

export const errorMsg = (data) =>{
    NotificationManager.error(data);
}

export const getUser = () =>{
    let temp = JSON.parse(sessionStorage.getItem("user"))
    return temp;
}