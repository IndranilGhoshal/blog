import React, { useEffect, useState } from 'react'
import Page from './page'
import { useNavigate } from 'react-router-dom';
import { errorMsg, getUser, successMsg } from '../../../service/common';
import { addPost, editPost, getPostbyId } from '../../../service/rest';
import { useParams } from 'react-router-dom'

export default function EditPost() {
    const { id } = useParams()

    const navigate = useNavigate();
    const [title, setTitle] = useState('')
    const [content, setContent] = useState('')
    const [titleErr, setTitleErr] = useState(false)
    const [contentErr, setContentErr] = useState(false)

    useEffect(() => {
        getPostbyIdFun(id)
    }, [])

    const getPostbyIdFun = (val) => {
        getPostbyId({ id: val }).then((result) => {
            if (result.data.success) {
                let res = result.data.response
                setTitle(res.title)
                setContent(res.content)
            }
        })
    }

    const getTitle = (val) => {
        setTitle(val)
        setTitleErr(false)
    }

    const getContent = (val) => {
        setContent(val)
        setContentErr(false)
    }

    const onSubmit = () => {
        let err = 0;
        setTitleErr(false)
        setContentErr(false)

        if (title === '' || title === undefined || title === null) {
            setTitleErr(true)
            err++
        }

        if (content === '' || content === undefined || content === null) {
            setContentErr(true)
            err++
        }

        if (err === 0) {
            let data = {
                id: id,
                title: title,
                content: content
            }
            editPost(data).then((result) => {
                if (result.data.success) {
                    successMsg(result.data.message)
                    setTimeout(() => {
                        navigate("/viewpost/" + id)

                    }, 1000);
                } else {
                    errorMsg(result.data.message)
                }
            })
        }
    }

    const goto = (path) => {
        navigate(path)
    }



    return (
        <Page
            title={title}
            content={content}
            titleErr={titleErr}
            contentErr={contentErr}

            getTitle={getTitle}
            getContent={getContent}
            onSubmit={onSubmit}
            goto={goto}
        />
    )
}
