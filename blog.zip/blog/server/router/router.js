const express = require('express');
const router = express.Router();

const user = require('../controller/user_controller')
const post = require('../controller/post_controller')
const comment = require('../controller/comment_controller')

router.use('/user', user );
router.use('/post', post );
router.use('/comment', comment );

module.exports = router;