import React from 'react'
const no_img_found = require('../../../assets/images/img_not_found.jpg')
export default function page(props) {
  return (
    <>
      <div className='hm_bdy'>
      <div className='pst_hd_txt my-3'>All Posts</div>
      <div>
        {
          props.postArr.length===0?
          <>
          <div className='row'>
            <div className='col-sm-12 text-center'>
              <div className='pot_no_im'>
                  <img src={no_img_found} alt="" />
              </div>
              <div className='pot_no_tx'>No Data Found!</div>
            </div>
          </div>
          </>
          :
          <>
          {
            props.postArr.map((item,i)=>(
              <div className={`pst_crd cursor-pointer ${props.postArr.length>1?"mt-3":""}`} onClick={()=>{props.goto("/viewpost/"+item.id)}}>
                <div className='row'>
                  <div className='col-sm-6'>
                    <div className='crd_txt_1'>
                      Title
                    </div>
                    <div className='crd_txt_2'>
                      {item.title}
                    </div>
                  </div>
                  <div className='col-sm-6 '>
                    <div className='crd_txt_1'>
                      Author
                    </div>
                    <div className='crd_txt_2'>
                      {item.author}
                    </div>
                  </div>
                  <div className='col-sm-12 mb-2'>
                    <div className='crd_txt_1'>
                      Content
                    </div>
                    <div className='crd_txt_2'>
                      {item.content}
                    </div>
                  </div>
                </div>

              </div>
            ))
          }
          </>
        }
      </div>
      </div>
      
    </>
  )
}
