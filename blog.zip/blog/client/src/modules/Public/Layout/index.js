import React from 'react'
import Page from './page'
import { useNavigate } from 'react-router-dom'
export default function Layout() {
  const navigate = useNavigate()
  const goto = (path)=>{
    navigate(path)
  }
  const logoutFun =()=>{
    sessionStorage.removeItem('user')
    navigate("/login")
  }
  return (
    <Page 
    goto={goto}
    logoutFun={logoutFun}
    />
  )
}
