import React, { useEffect, useState } from 'react'
import Page from './page'
import { useParams, useNavigate } from 'react-router-dom'
import { addComment, allComment, deletePost, getPostbyId } from '../../../service/rest'
import { errorMsg, getUser, successMsg } from '../../../service/common'
export default function ViewPost() {
    const [post, setPost] = useState({})
    const [comment, setComment] = useState([])
    const { id } = useParams()
    const navigate = useNavigate()
    const [content, setContent] = useState('')
    const [contentErr, setContentErr] = useState(false)


    const getContent = (val) => {
        setContent(val)
        setContentErr(false)
    }

    useEffect(() => {
        getPostbyIdFun(id)
        getAllCommentFun(id)
    }, [])

    const getPostbyIdFun = (val) => {
        getPostbyId({ id: val }).then((result) => {
            if (result.data.success) {
                setPost(result.data.response)
            } else {
                setPost({})
            }
        })
    }

    const getAllCommentFun = (val) => {
        allComment({ postid: val }).then((result) => {
            if (result.data.success) {
                setComment(result.data.response)
            } else {
                setComment([])
            }
        })
    }

    const onSubmit = () => {
        let err = 0;
        setContentErr(false)
    
        if (content === '' || content === undefined || content === null) {
          setContentErr(true)
          err++
        }
    
        if (err === 0) {
          let data = {
            userid:getUser().id,
            postid:id,
            content:content
          }
          addComment(data).then((result) => {
            if (result.data.success) {
              successMsg(result.data.message)
              setContent('')
              getAllCommentFun(id)
            } else {
              errorMsg(result.data.message)
            }
          })
        }
      }

      const goto =(path) =>{
        navigate(path)
      }

      const onDelete = (val) =>{
        deletePost({id:val}).then((result)=>{
          if(result.data.success){
            successMsg(result.data.message)
            navigate("/")
          }else {
            errorMsg(result.data.message)
          }
        })
      }


    return (
        <Page
            post={post}
            content={content}
            contentErr={contentErr}
            getContent={getContent}
            onSubmit={onSubmit}
            comment={comment}
            goto={goto}
            onDelete={onDelete}
        />
    )
}
